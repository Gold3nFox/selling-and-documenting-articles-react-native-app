import React, { Component } from 'react';
import { Container, Header,Toast, Content,View, Form, Button, Item, Input, Icon,Left,Right,Body,Title } from 'native-base';
import {Text, Image, BackHandler,ActivityIndicator,Dimensions} from 'react-native';
import Spinner from 'react-native-loading-spinner-overlay';

var API_URL = require('../config/config.js');

class cataloguepage extends Component {
constructor(props) {
      super(props);
      this.state = {
        response : [],
        pageNumber : 1,
        page : 1,
        maxpage : 1,
        loading:true,
        lastnum : 1,
        renderer : []
      };
      global.renderer = [];
    }

    fetch_cataloguepages() {
      setTimeout(() => {
        this.setState({loading:false});
      }, 2000);
      fetch(API_URL + '/auth/getCataloguePage?pagenumber=' + this.state.pageNumber + '&catalogue_id=' + this.props.navigation.getParam('catalogue_id')
      , {
        method: 'POST',
        headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
        'Authorization': 'Bearer '+window.access_token,
        },
      }).then((response) => response.json())
      .then((responseJson) => {
        variable = responseJson + '';
        if(variable != 'undefined'){
          // alert(JSON.stringify(responseJson[0].pagenumber));
          var countType = Object.keys(responseJson).length;
            for(let i = 0 ; i < countType ; i++){
              global.renderer[i] = i;
            }
            this.setState({response : responseJson,maxpage:this.props.navigation.getParam('pagenumber'),loading:false});
        }
        this.forceUpdate();
      })
      .catch((error) => {
          Toast.show({        text: 'اختلال در اتصال به شبکه',       textStyle: { textAlign: "right",color:'red' },       duration: 3000     });
      });
    }

    getimage(){
      // alert(JSON.stringify(this.state.response) +  '    ' + this.state.response[this.state.page-1]);
      if(this.state.response[0] != undefined && this.state.page == this.state.lastnum && this.state.response[this.state.page-1]!= undefined)
        {
          // alert( this.props.navigation.getParam('catalogue_id')+'  ' +this.state.response[this.state.page-1].imageURL);
        return (this.state.response[this.state.page-1].imageURL);
        }
        else
          return '';
    }

    getButton(){
      // alert(JSON.stringify(this.state.response) +  '    ' + this.state.response[this.state.page-1]);
      if(this.state.response[0] != undefined && this.state.page == this.state.lastnum && this.state.response[this.state.page-1]!= undefined)
        {
          if(this.state.response[this.state.page-1].product_id != null){
            return (
            <Button transparent style={{flex:1,position: 'absolute',width:this.state.response[this.state.page-1].width+"%",height:null,aspectRatio:1,left:this.state.response[this.state.page-1].left+"%",top:this.state.response[this.state.page-1].top+"%"}} onPress={()=>{this.props.navigation.navigate('ProductSeries',{name : this.state.response[this.state.page-1].name,route:'cataloguepage',catid:this.props.navigation.getParam('catalogue_id'),id : this.state.response[this.state.page-1].product_id,family : this.state.response[this.state.page-1].family, imageURL : this.state.response[this.state.page-1].fimageURL})}} >
              <Image source={require('./catalogbuy.png')} style={{flex:1,height:'100%',width:null,aspectRatio:1}} />
            </Button>
            );
          }
        }
        else
          return (<View></View>);
    }

  componentWillMount(){
    this.backHandler = BackHandler.addEventListener('hardwareBackPress', () => {
      this.props.navigation.navigate('catalogue');
      return true;
    });
    this.fetch_cataloguepages();

  }
  
  render() {
    return (
      <Container>

        <Header style={{height:Dimensions.get('window').height*1/10,borderBottomStartRadius:10,borderBottomEndRadius:10,backgroundColor:'#336799'}}>
        <Left style={{flex:0.5}}>
            <Button transparent onPress={()=>{this.props.navigation.navigate('catalogue')}}>
            <Icon name='arrow-back'  style={{height:Dimensions.get('window').width*1/15,color: "white",width:'20%',fontSize:Dimensions.get('window').width*1/15}} />
            </Button>
        </Left>
        <Body style={{flex:0.2,flexDirection:'row', justifyContent: "space-between", alignItems: "center", }}>
              <Input numberOfLines={1}
                style={{color:"white",backgroundColor:'#336799'}}
                onSubmitEditing={()=>{
                  if(parseInt(this.state.lastnum) < (parseInt(this.state.maxpage) + 1) & parseInt(this.state.lastnum) > 0){
                    if(parseInt(this.state.lastnum) > 0){
                      this.setState({page:this.state.lastnum});
                    }else{
                      this.setState({lastnum:this.state.page});
                    }
                  }else{
                    this.setState({lastnum:this.state.page});
                  }
                }}
                onChangeText={(text) => {
                    this.setState({lastnum : text});
                }}
                value={this.state.lastnum+""}
              />
              <Text style={{fontSize:17,color:"white",}}>/ {this.state.maxpage}</Text>
        </Body>
        <Right style={{flex:0.5}}>
            <Title style={{fontFamily:'mjsaudiarab',fontSize:Dimensions.get('window').height*1/35}}>کاتالوگ</Title>
        </Right>
      </Header>
        

        <Spinner
          visible={this.state.loading}
          overlayColor={"rgba(0, 0, 0, 0.8)"}
          textContent={'در حال دریافت تصویر...'}
          textStyle={{direction:'rtl',fontFamily:'mjsaudiarab',color: '#FFF'}}
          />
        <Image source={{uri:this.getimage()}} style={{flex:1, height: undefined, width: undefined,resizeMode:'stretch'}} onLoadStart={() => {this.setState({loading:true}); setTimeout(() => {
        this.setState({loading:false});
      }, 2000); }} onLoadEnd={() => { this.setState({loading:false})}} onError={() => {this.setState({loading:false}) }} />
            <Button transparent style={{position:'absolute',width:'20%',alignSelf:'center',right:'1%',top:"50%",height:Dimensions.get('window').height*1/10}} full rounded
             onPress={()=> {if(this.state.lastnum<this.state.maxpage){this.setState({lastnum : parseInt(this.state.lastnum) + 1,page: parseInt(this.state.lastnum) + 1})}}}>
            <Icon name="arrow-forward" style={{color:"'rgba(77,77,77,1)'",fontSize:40}}></Icon>
            </Button>


            
            <Button transparent style={{position:'absolute',alignSelf:'center',width:'20%',left:'1%',top:"50%",height:Dimensions.get('window').height*1/10}} full rounded
            onPress={()=> {if(this.state.lastnum>1){this.setState({lastnum : parseInt(this.state.lastnum) - 1,page: parseInt(this.state.lastnum) - 1})}}}>
            <Icon name="arrow-back" style={{color:"'rgba(77,77,77,1)'",fontSize:40}}></Icon>
            </Button>
            {this.getButton()}
      
      </Container>
    );
  }
}

export default cataloguepage;