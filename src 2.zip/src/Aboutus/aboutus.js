import React, { Component } from 'react';
import { Image,BackHandler,View,Dimensions } from 'react-native';
import { Container,Title,Right, Header, Content, Card, CardItem, Thumbnail, Text, Button, Icon, Left, Body } from 'native-base';
export default class aboutus extends Component {
  
  componentWillMount() {
    this.backHandler = BackHandler.addEventListener('hardwareBackPress', () => {
      this.props.navigation.navigate('MainPage');
      return true;
    });

  }
  
  componentWillUnmount() {
    this.backHandler.remove();
  }
  render() {
    return (
    <Container style={{backgroundColor:'#00ccff'}}>
        <Header style={{height:Dimensions.get('window').height*1/10,borderBottomStartRadius:10,borderBottomEndRadius:10,backgroundColor:'#336799'}}>
        <Left style={{flex:0.3}}>
            <Button transparent onPress={()=>{this.props.navigation.openDrawer();}}>
            <Image source={require('../home/001.png')} style={{width:Dimensions.get('window').height*1/23,height:Dimensions.get('window').height*1/23}} />
            </Button>
        </Left>
        <Right style={{flex:0.7}}>
            <Title style={{fontFamily:'mjsaudiarab',fontSize:Dimensions.get('window').height*1/35}}>درباره بروکس</Title>
        </Right>
      </Header>

        <Content>
            <CardItem style={{marginTop:Dimensions.get('window').height*1/15,backgroundColor:'#00ccff',justifyContent: 'center',alignContent:'center',alignItems:'center'}}>
                  <Text style={{textAlign:'center',fontFamily:'mjsaudiarab',fontSize:Dimensions.get('window').height*1/25,color:'#666666'}}>درباره بروکس</Text>
            </CardItem>
              <CardItem style={{backgroundColor:'#00ccff',justifyContent: 'center',alignContent:'center',width:'100%',alignItems:'center',alignSelf:'center'}}>
                <View style={{left:'3%',right:'3%',width:'94%',justifyContent: 'center',alignContent:'center',alignItems:'center',alignSelf:'center'}}>
                  <Text style={{fontFamily:'mjsaudiarab',fontSize:Dimensions.get('window').height*1/40,lineHeight:Dimensions.get('window').height*1/35,justifyContent:'space-between',direction:'ltr',textAlign:'right',alignSelf:'center',color:'#666666'}}> بهره مندی از شبکه فروش سازمانی و مویرگی بهره مندی از شبکه فروش سازمانی و مویرگی بهره مندی از شبکه فروش سازمانی و مویرگی بهره مندی از شبکه فروش سازمانی و مویرگی بهره مندی از شبکه فروش سازمانی و مویرگی بهره مندی از شبکه فروش سازمانی و مویرگی بهره مندی از شبکه فروش سازمانی و مویرگی</Text>
                </View>
              </CardItem>
              <CardItem style={{backgroundColor:'#00ccff'}}>
              <Body><Image source={require('./logowhite.png')} style={{width: Dimensions.get('window').width*1/4,height:Dimensions.get('window').width*1/4,marginVertical:20,aspectRatio:1,flex: 1,justifyContent:'center',alignContent:'center',alignSelf:'center'}}/></Body>
              </CardItem>
        </Content>
      </Container>
    );
  }
}