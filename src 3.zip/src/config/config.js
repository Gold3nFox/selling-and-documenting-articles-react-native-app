'use strict';

var API_URL = 'http://104.248.251.209/api';

module.exports = API_URL;