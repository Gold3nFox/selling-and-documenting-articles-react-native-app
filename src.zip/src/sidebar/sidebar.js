import React, { Component } from 'react';
import { AppRegistry, Image,View, StatusBar, TouchableOpacity,Linking } from "react-native";
import {
  Text,
  Container,
  List,
  Content,
  Icon,
  Left,
  Body,
  Right
} from "native-base";
export default class Side333Bar extends React.Component {

  render() {
    return (
      <Container style={{backgroundColor: 'rgba(0,0,0,0.1)'}}>
        <View style={{flex:1}} >
          <Image
            style={{
              height: "30%",
              width: "100%",
              alignSelf: "stretch",
              marginBottom:' 1%'
            }}
            source={{uri : "http://195.248.241.97/assets/sidebar/001.png"}}
          />

          {/* <Image srouce={{uri : "http://195.248.241.97/assets/sidebar/002.png"}} style={{ position:'absolute' , height:'100%', width:'100%'}} /> */}

          
          <View
                style = {{marginBottom:'1%',width:"100%", height:"11.6%" , alignContent:"flex-end",justifyContent:"flex-end",textAlign:"right",alignViews:"flex-end"}}>
                <TouchableOpacity style={{position: 'absolute',width:'100%',height:'100%'}} onPress={() => {this.props.navigation.navigate('MainPage')}}>
                <Image source={{uri : "http://195.248.241.97/assets/sidebar/002.png"}} style={{position: 'absolute',height:"100%",width:"100%",alignSelf: "stretch",}} />
                <Text style = {{justifyContent:"flex-end",color:"'rgba(77,77,77,1)'",textAlign:"right",alignViews:"flex-end",marginRight:40,top:"40%",fontFamily:'Mj_Saudi Arabia',fontSize:20  }}>خانه</Text>
                </TouchableOpacity>
          </View>
          

          <View
                style = {{marginBottom:' 1%',width:"100%", height:"11.6%" , alignContent:"flex-end",justifyContent:"flex-end",textAlign:"right",alignViews:"flex-end"}}>
                <TouchableOpacity style={{width:'100%',height:'100%'}} onPress={() => {this.props.navigation.navigate('ProductPage')}}>
                <Image source={{uri : "http://195.248.241.97/assets/sidebar/003.png"}} style={{position: 'absolute',height:"100%",width:"100%",alignSelf: "stretch",}} />
                <Text style = {{justifyContent:"flex-end",color:"'rgba(77,77,77,1)'",textAlign:"right",alignViews:"flex-end",marginRight:40,top:'40%',fontFamily:'Mj_Saudi Arabia',fontSize:20  }}>محصولات جدید</Text>
                </TouchableOpacity>
          </View>

          <View
                style = {{marginBottom:' 1%',width:"100%", height:"11.6%" , alignContent:"flex-end",justifyContent:"flex-end",textAlign:"right",alignViews:"flex-end"}}>
                <TouchableOpacity style={{width:'100%',height:'100%'}} onPress={() => {this.props.navigation.navigate('NewsPage')}}>
                <Image source={{uri : "http://195.248.241.97/assets/sidebar/004.png"}} style={{position: 'absolute',height:"100%",width:"100%",alignSelf: "stretch",}} />
                <Text style = {{justifyContent:"flex-end",color:"'rgba(77,77,77,1)'",textAlign:"right",alignViews:"flex-end" ,marginRight:40,top:"30%",fontFamily:'Mj_Saudi Arabia',fontSize:20 }}>اخبار</Text>
                </TouchableOpacity>
          </View>

          <View
                style = {{marginBottom:' 1%',width:"100%", height:"11.6%" , alignContent:"flex-end",justifyContent:"flex-end",textAlign:"right",alignViews:"flex-end"}}>
                <TouchableOpacity style={{width:'100%',height:'100%'}} onPress={() => {this.props.navigation.navigate('aboutus')}}>
                <Image source={{uri : "http://195.248.241.97/assets/sidebar/005.png"}} style={{position: 'absolute',height:"100%",width:"100%",alignSelf: "stretch",}} />
                <Text style = {{justifyContent:"flex-end",color:"'rgba(77,77,77,1)'",textAlign:"right",alignViews:"flex-end" ,marginRight:40,top:"30%",fontFamily:'Mj_Saudi Arabia',fontSize:20}}>درباره ما</Text>
                </TouchableOpacity>
          </View>

          <View
                style = {{marginBottom:' 1%',width:"100%", height:"11.6%" , alignContent:"flex-end",justifyContent:"flex-end",textAlign:"right",alignViews:"flex-end"}}>
                <TouchableOpacity style={{width:'100%',height:'100%'}} onPress={() => {this.props.navigation.navigate('starter')}}>
                <Image source={{uri : "http://195.248.241.97/assets/sidebar/006.png"}} style={{position: 'absolute',height:"100%",width:"100%",alignSelf: "stretch",}} />
                <Text style = {{justifyContent:"flex-end",color:"'rgba(77,77,77,1)'",textAlign:"right",alignViews:"flex-end",marginRight:40,top:"30%",fontFamily:'Mj_Saudi Arabia',fontSize:20  }}>خروج</Text>
                </TouchableOpacity>
          </View>

          <TouchableOpacity onPress={()=>{Linking.openURL('https://burux.com')}}>
          <View style={{backgroundColor:"'rgba(0,0,0,0.6)'"}}>
                {/* // style = {{marginBottom:' 1%',width:"100%", height:"11.6%" , alignContent:"flex-end",justifyContent:"flex-end",textAlign:"right",alignViews:"flex-end"}}> */}
                {/* <Image source={{uri : "https://image.ibb.co/bPMoi0/Screen-Shot-2018-10-17-at-12-41-05-PM.png"}} style={{position: 'absolute',height:"100%",width:"100%",alignSelf: "stretch",}} /> */}
                <Text style={{fontSize:30,top:10,height:'100%',textAlign:'center',fontFamily:'Mj_Saudi Arabia',color:"'rgba(77,77,77,1)'",backgroundColor:"'rgba(0,0,0,1)'"}}>www.burux.com</Text>
          </View>
          </TouchableOpacity>
        </View>
      </Container>
    );
  }
}