import React, { Component } from 'react';
import { Image, Alert,TouchableOpacity, View, ListView,BackHandler } from 'react-native';
import Dialog from "react-native-dialog";
import { Container, Header, Content, Card, Radio, CardItem, Thumbnail, Text, Button, Icon, Left, Body, Right, Title } from 'native-base';
import Spinner from 'react-native-loading-spinner-overlay';
var API_URL = require('../config/config.js');

class basket extends Component {
  constructor(props) {
    super(props);
    this.state =  {
      dialogVisible: false,
      productName : "",
      count : 1,
      response : [],
      renderer: [],
      loading:true,
      text:'در حال دریافت سبد خرید...',
      empty : 0
    };
    global.renderer = [];
  }

      showDialog = () => {
        this.setState({ dialogVisible: true });
      };
    
      handleYes = () => {
        this.setState({ dialogVisible: false,loading:true,text:"در حال بررسی سفارش..." });
        if(this.state.empty != 1 )
          this.make_order();
        this.setState({count : 1});
      };
    
      handleNo = () => {
        this.setState({ dialogVisible: false });
        this.setState({count : 1});
      };

      fetch_basket () {
        fetch(API_URL + '/auth/showBasket' 
        , {
          method: 'POST',
          headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
          'Authorization': 'Bearer '+window.access_token,
          },
        }).then((response) => response.json())
        .then((responseJson) => {
          variable = responseJson + '';
          if(variable != 'undefined'){
            var countType = Object.keys(responseJson).length;
            for(let i = 0 ; i < countType ; i++){
              global.renderer[i] = i;
            }
            this.setState({response : responseJson,renderer : global.renderer,loading:false});
            if(responseJson.length == 0){
              this.setState({empty : 1})
            }
          }
          this.forceUpdate();
        })
        .catch((error) => {
            console.error(error);
        });
      }

      remove_basket (rowData) {
        this.setState({loading:true,text:'در حال حذف کالا...'});
        fetch(API_URL + '/auth/deletBasketItem?product_id='+this.state.response[rowData].product_id 
        , {
          method: 'POST',
          headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
          'Authorization': 'Bearer '+window.access_token,
          },
        }).then((response) => response.json())
        .then((responseJson) => {
          variable = responseJson + '';
          if(variable != 'undefined'){
            global.renderer = [];
            this.setState({response:[],renderer:global.renderer,text:'در حال دریافت سبد خرید...'});
            this.fetch_basket();
          }
        })
        .catch((error) => {
            console.error(error);
        });
      }


      make_order () {
        fetch(API_URL + '/auth/addToOrders' 
        , {
          method: 'POST',
          headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
          'Authorization': 'Bearer '+window.access_token,
          },
        }).then((response) => response.json())
        .then((responseJson) => {
          variable = responseJson + '';
          if(variable != 'undefined'){
            this.props.navigation.navigate('orders');
            this.setState({loading:false,text:'در حال دریافت سبد خرید...'});
          }
        })
        .catch((error) => {
            this.setState({loading:false,text:'در حال دریافت سبد خرید...'});
            console.error(error);
        });
      }


      getrenderer(){
        if(this.state.response != undefined){
          return this.state.renderer;
        }else{
          return [];
        }
      }

      componentWillMount(){
        this.backHandler = BackHandler.addEventListener('hardwareBackPress', () => {
          this.props.navigation.navigate('MainPage');
          return true;
        });
        this.fetch_basket();
      }

      getImage(rowData){
        if(this.state.response[rowData] != undefined){
          return this.state.response[rowData].imageURL;
        }else
          return "";
      }
      isempty(){
        if(this.state.empty == 1){
          return (
              <Text>
                {/* <Image  source={{uri : 'https://khaterat.mobi/js/LogoTamas.jpg'}} style={{height: 193,width: 134.3,flex: 1,left:'25%'}}/> */}
                <Text style ={{marginTop:35,marginBottom:35,textAlign: 'center', alignSelf: 'stretch'}}>
                سبد خرید شما خالی است
                </Text>
              </Text>
              );
        }else
          return;
      }

      getFamily(rowData){
        if(this.state.response[rowData] != undefined){
          return this.state.response[rowData].family;
        }else{
          return "";
        }
      }
      getCount(rowData){
        if(this.state.response[rowData] != undefined){
          return this.state.response[rowData].count;
        }else{
          return "";
        }
      }
      getName(rowData){
        if(this.state.response[rowData] != undefined){
          return this.state.response[rowData].name;
        }else{
          return "";
        }
      }
      getColor(rowData){
        if(this.state.response[rowData] != undefined){
          return this.state.response[rowData].color;
        }else{
          return "";
        }
      } 
      getWatt(rowData){
        if(this.state.response[rowData] != undefined){
          return this.state.response[rowData].watt;
        }else{
          return "";
        }
      }

    render(){
    return (
      <Container>

      <Header style={{borderBottomStartRadius:10,borderBottomEndRadius:10,backgroundColor:'#336799'}}>
        <Left>
            <Button transparent onPress={()=>{this.props.navigation.navigate('MainPage')}}>
            <Icon name='arrow-back'  style={{color: "white"}}/>
            </Button>
        </Left>
        <Right style={{flex:0.5}}>
            <Title style={{fontFamily:'Mj_Saudi Arabia'}}>سبد خرید</Title>
        </Right>
      </Header>
        <Content>
        <Spinner
          visible={this.state.loading}
          overlayColor={"rgba(0, 0, 0, 0.8)"}
          textContent={this.state.text}
          textStyle={{direction:'rtl',fontFamily:'Mj_Saudi Arabia',color: '#FFF'}}
          />
            <Dialog.Container visible={this.state.dialogVisible}>
            <Dialog.Title>خرید کالا</Dialog.Title>
            <Dialog.Description>
                آیا از سفارشات خود مطمئن هستید؟
            </Dialog.Description>
            <Dialog.Button label="بله" onPress={this.handleYes} />
            <Dialog.Button label="خیر" onPress={this.handleNo} />
            </Dialog.Container>


            <ListView
                ref="ListView"
                
                dataSource ={ new ListView.DataSource({
                  rowHasChanged: (r1, r2) => r1 !== r2
                  }).cloneWithRows(this.getrenderer())
                }
                
                renderRow={(rowData) => (
                  <Card>
                    <CardItem>
                    <Left>
                      <Thumbnail style={{left:0,width:150,aspectRatio:1}} square source={{uri:this.getImage(rowData)}} />
                    </Left>
                    <Right>
                        <TouchableOpacity onPress={()=>{this.remove_basket(rowData)}}>
                            <Icon style={{color:'red',fontSize:30}} name="close"></Icon>
                        </TouchableOpacity>
                        <Text>خانواده {this.getFamily(rowData)}</Text>
                        <Text note>سری {this.getName(rowData)}</Text>
                        <View style={{flexDirection: 'row',}}>
                          <Text>تعداد : {this.getCount(rowData)}</Text>
                        </View>
                        <Text>{this.getColor(rowData)} رنگ</Text>
                        <Text>{this.getWatt(rowData)} وات</Text>
                    </Right>
                  </CardItem>
              </Card>
                )}
            />

            {this.isempty()}
            
           <Card>
                <Button block
                style={{width:"100%"}}
                onPress={()=>{
                    this.setState({productName: "حبابی 12 وات مهتابی"});
                    this.showDialog();
                    }}>
                  <Icon active name="checkmark" />
                  <Text>تایید سفارشات</Text>
                </Button>
            </Card>
        
        </Content>

      </Container>
    );
  }
}

export default basket;