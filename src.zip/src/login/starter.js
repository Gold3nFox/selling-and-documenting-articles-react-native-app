import React, { Component } from 'react';
import { Container, Header, Content, Form, Button } from 'native-base';
import {Text, Image,BackHandler,View} from 'react-native';

class starter extends Component {
constructor(props) {
      super(props);
      this.state = {
        isOpen: false,
        isDisabled: false,
        swipeToClose: true,
        sliderValue: 0.3,
        mobileNumber: '', 
        verCode: ''
      };
    }

  componentWillMount(){
    this.backHandler = BackHandler.addEventListener('hardwareBackPress', () => {
      BackHandler.exitApp();
      return true;
    });
    console.disableYellowBox = true;
  }

  
  render() {
    return (
      <Container>
        
        <Image source={{uri:"http://195.248.241.97/assets/starter/004.png"}} style={{left:0,position:"absolute", width:"100%", height:"100%", resizeMode:'stretch'}} />
        
        <Content>



        <Image source={{uri:"http://195.248.241.97/assets/ProductList/007.png"}} style={{width:75, height:24,top:"10%", alignSelf:'center'}} />
        <Image source={{uri:"http://195.248.241.97/assets/ProductList/005.png"}} style={{width:150, height:150,top:"20%", alignSelf:'center'}} />
            <Button style={{alignSelf:'center',flex: 1,marginTop:150, justifyContent: 'center',alignItems: 'center',backgroundColor:'#008ed8', width:'40%', borderRadius:8}} full blocked
             onPress={()=> {this.props.navigation.navigate('LoginPage')}}>
            {/* <Text style={{textAlignVertical: 'center',marginTop:0,color:'#89fafa',alignItems:'center',alignSelf:'center',justifyContent: 'center', fontFamily:'Mj_Saudi Arabia', fontSize:17,lineHeight:17}}>ورود</Text> */}
            <Text style={{color:'#89fafa',fontSize:17,lineHeight:17}}>ورود</Text>
            </Button>

            <Button style={{alignSelf:'center',flex: 1,marginTop:25, justifyContent: 'center',alignItems: 'center',backgroundColor:'#008ed8', width:'40%', borderRadius:8}} full blocked
             onPress={()=> {this.props.navigation.navigate('RegisterPage')}}>
            {/* <Text style={{textAlignVertical: 'center',marginTop:0,color:'#89fafa',alignItems:'center',alignSelf:'center',justifyContent: 'center', fontFamily:'Mj_Saudi Arabia', fontSize:17,lineHeight:17}}>ورود</Text> */}
            <Text style={{color:'#89fafa',fontSize:17,lineHeight:17}}>عضویت</Text>
            </Button>
            
        </Content>
      
      </Container>
    );
  }
}

export default starter;