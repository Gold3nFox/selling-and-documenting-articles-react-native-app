import React, { Component } from 'react';
import { Container, Header, Body, Content, Form, Item, Input, Label, Button, Icon, Right, Left, Title, Card, CardItem, Thumbnail } from 'native-base';
import {WebView,BackHandler} from 'react-native';
import Spinner from 'react-native-loading-spinner-overlay';

class pdf extends React.Component {
    constructor(props) {
        super(props);
        this.state =  {
          loading:true
        };
      }

    componentWillMount(){
        this.backHandler = BackHandler.addEventListener('hardwareBackPress', () => {
            this.props.navigation.navigate('photonPage');
            return true;
          });
    }

    render() {
    return (
    <Container>

    <Header  style={{borderBottomStartRadius:10,borderBottomEndRadius:10,backgroundColor:'#336799'}}>
    <Left>
        <Button transparent
        onPress={()=>{this.props.navigation.navigate('photonPage')}}
        >
        <Icon name='arrow-back'  style={{color: "white"}}/>
        </Button>
    </Left>
    <Right style={{flex:1}}>
        <Title>فوتون</Title>
    </Right>
    </Header>

    <Spinner
          visible={this.state.loading}
          overlayColor={"rgba(0, 0, 0, 0.8)"}
          textContent={'در حال دریافت فوتون...'}
          textStyle={{direction:'rtl',fontFamily:'Mj_Saudi Arabia',color: '#FFF'}}
          />
    
    <WebView onLoadEnd={e => this.setState({loading:false})} onError={e => this.setState({loading:false})}  source={{uri: this.props.navigation.getParam('pdfURL')}}>
    </WebView>

    </Container>

    )}
}

export default pdf;