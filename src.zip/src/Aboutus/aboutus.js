import React, { Component } from 'react';
import { Image,BackHandler } from 'react-native';
import { Container,Title,Right, Header, Content, Card, CardItem, Thumbnail, Text, Button, Icon, Left, Body } from 'native-base';
export default class aboutus extends Component {
  
  componentWillMount() {
    this.backHandler = BackHandler.addEventListener('hardwareBackPress', () => {
      this.props.navigation.navigate('MainPage');
      return true;
    });

  }
  
  componentWillUnmount() {
    this.backHandler.remove();
  }
  render() {
    return (
    <Container style={{backgroundColor:'#00ccff'}}>
        <Header style={{borderBottomStartRadius:10,borderBottomEndRadius:10,backgroundColor:'#336799'}}>
        <Left>
            <Button transparent onPress={()=>{this.props.navigation.openDrawer();}}>
            <Image source={{uri : "https://image.ibb.co/iZdQVf/001.png"}} style={{width:30,height:30}} />
            </Button>
        </Left>
        <Right style={{flex:0.5}}>
            <Title style={{fontFamily:'Mj_Saudi Arabia'}}>درباره ما</Title>
        </Right>
      </Header>

        <Content>
        <Thumbnail square style={{width : 190,height : 60,marginBottom:60,top:40,textAlign:'center',alignContent:'center',alignSelf:'center'}} source={{uri : 'http://195.248.241.97/assets/ProductList/007.png'}} />
          <Card style={{flex: 0}}>
            <CardItem>
              <Left>
                <Thumbnail square style={{width : 120,height : 60}} source={{uri : 'http://195.248.241.97/assets/ProductList/007.png'}} />
                <Right>
                  <Text>بروکس</Text>
                </Right>
              </Left>
            </CardItem>
            <CardItem>
              <Body><Image  source={{uri : 'http://195.248.241.97/assets/ProductList/005.png'}} style={{height: 150,width: 150,flex: 1,left:100}}/></Body>
              </CardItem>
            <CardItem>
              <Body>
                {/* <Image  source={{uri : 'https://khaterat.mobi/js/LogoTamas.jpg'}} style={{height: 193,width: 134.3,flex: 1,left:'25%'}}/> */}
                <Text style ={{marginTop:15,textAlign: 'right', alignSelf: 'stretch'}}>
                شرکت بروکس ..
                </Text>
              </Body>
            </CardItem>
          </Card>
        </Content>
      </Container>
    );
  }
}