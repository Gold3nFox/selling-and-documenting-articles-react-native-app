'use strict';

var API_URL = 'http://195.248.241.97/api';

module.exports = API_URL;