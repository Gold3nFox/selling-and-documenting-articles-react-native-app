'use strict';

var PatternID = 'e751889f-bd7d-4e4e-a49d-9580a1c564b8';

module.exports = PatternID;