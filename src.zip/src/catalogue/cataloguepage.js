import React, { Component } from 'react';
import { Container, Header, Content, Form, Button, Item, Input, Icon,Left,Right,Body,Title } from 'native-base';
import {Text, Image, BackHandler} from 'react-native';
import Spinner from 'react-native-loading-spinner-overlay';

var API_URL = require('../config/config.js');

class cataloguepage extends Component {
constructor(props) {
      super(props);
      this.state = {
        response : [],
        pageNumber : 1,
        page : 1,
        maxpage : 1,
        loading:true,
        lastnum : 1,
        renderer : []
      };
      global.renderer = [];
    }

    fetch_cataloguepages() {
      fetch(API_URL + '/auth/getCataloguePage?pagenumber=' + this.state.pageNumber + '&catalogue_id=' + this.props.navigation.getParam('catalogue_id')
      , {
        method: 'POST',
        headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
        'Authorization': 'Bearer '+window.access_token,
        },
      }).then((response) => response.json())
      .then((responseJson) => {
        variable = responseJson + '';
        if(variable != 'undefined'){
          // alert(JSON.stringify(responseJson[0].pagenumber));
          var countType = Object.keys(responseJson).length;
            for(let i = 0 ; i < countType ; i++){
              global.renderer[i] = i;
            }
            this.setState({response : responseJson,maxpage:this.props.navigation.getParam('pagenumber'),loading:false});
        }
        this.forceUpdate();
      })
      .catch((error) => {
          console.error(error);
      });
    }

    getimage(){
      // alert(JSON.stringify(this.state.response) +  '    ' + this.state.response[this.state.page-1]);
      if(this.state.response[0] != undefined && this.state.page == this.state.lastnum && this.state.response[this.state.page-1]!= undefined)
        {
          // alert( this.state.page+'  ' +this.state.response[this.state.page-1].imageURL);
        return (this.state.response[this.state.page-1].imageURL);
        }
        else
          return '';
    }

  componentWillMount(){
    this.backHandler = BackHandler.addEventListener('hardwareBackPress', () => {
      this.props.navigation.navigate('catalogue');
      return true;
    });
    this.fetch_cataloguepages();

  }
  
  render() {
    return (
      <Container>

        <Header style={{borderBottomStartRadius:10,borderBottomEndRadius:10,backgroundColor:'#336799'}}>
        <Left>
            <Button transparent onPress={()=>{this.props.navigation.navigate('catalogue')}}>
            <Icon name='arrow-back'  style={{color: "white"}} />
            </Button>
        </Left>
        <Right style={{flex:0.5}}>
            <Title style={{fontFamily:'Mj_Saudi Arabia'}}>کاتالوگ</Title>
        </Right>
      </Header>
        

        <Spinner
          visible={this.state.loading}
          overlayColor={"rgba(0, 0, 0, 0.8)"}
          textContent={'در حال دریافت اطلاعات کاتالوگ...'}
          textStyle={{direction:'rtl',fontFamily:'Mj_Saudi Arabia',color: '#FFF'}}
          />

        <Image source={{uri:this.getimage()}} style={{width:"100%", height:"100%"}} />
        

            <Button transparent style={{position:'absolute',width:'20%',alignSelf:'center',right:'1%',top:"50%"}} full rounded
             onPress={()=> {if(this.state.lastnum<this.state.maxpage){this.setState({lastnum : parseInt(this.state.lastnum) + 1,page: parseInt(this.state.lastnum) + 1})}}}>
            <Icon name="arrow-forward" style={{color:"'rgba(77,77,77,1)'",fontSize:40}}></Icon>
            </Button>

            <Item style={{width: '10%',left:"40%",position:'absolute',top:10}}>
              <Input numberOfLines={1}
                style={{color:"white",top:2,backgroundColor:'#336799'}}
                onSubmitEditing={()=>{
                  if(parseInt(this.state.lastnum) < (parseInt(this.state.maxpage) + 1) & parseInt(this.state.lastnum) > 0){
                    if(parseInt(this.state.lastnum) > 0){
                      this.setState({page:this.state.lastnum});
                    }else{
                      this.setState({lastnum:this.state.page});
                    }
                  }else{
                    this.setState({lastnum:this.state.page});
                  }
                }}
                onChangeText={(text) => {
                    this.setState({lastnum : text});
                }}
                value={this.state.lastnum+""}
              />
            </Item>

            <Text style={{width: '10%',height:21,position:'absolute',alignSelf:'center',left:"50%",top:25.5,fontSize:17,color:"white"}}>/ {this.state.maxpage}</Text>
            
            <Button transparent style={{position:'absolute',alignSelf:'center',width:'20%',left:'1%',top:"50%"}} full rounded
            onPress={()=> {if(this.state.lastnum>1){this.setState({lastnum : parseInt(this.state.lastnum) - 1,page: parseInt(this.state.lastnum) - 1})}}}>
            <Icon name="arrow-back" style={{color:"'rgba(77,77,77,1)'",fontSize:40}}></Icon>
            </Button>
      
      </Container>
    );
  }
}

export default cataloguepage;